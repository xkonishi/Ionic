import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { AccountActivityPage } from '../activity/account/account';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(
    public navCtrl: NavController) {

  }

  // 「取引先の活動登録」ボタン押下
  onClickBtn(event) {
    this.navCtrl.push(AccountActivityPage);
  }
}
