import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { AccountActivityPage } from '../activity/account/account';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  pushPage: any;

  constructor(public navCtrl: NavController) {

  }

  onClickBtn(event) {
    debugger;
    this.pushPage = AccountActivityPage;
  }
}
