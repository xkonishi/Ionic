import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { AlertController } from 'ionic-angular'

// force.js
declare let force: any;

@Component({
  selector: 'page-account',
  templateUrl: 'account.html'
})
export class AccountActivityPage {
  accountid: string;
  accountname: string;
  description: string;

  constructor(private navCtrl: NavController,
              private navParams: NavParams,
              private alertCtrl: AlertController) {

    this.accountid = navParams.get('id');
    this.accountname = navParams.get('name');      
  }

  // 「音声入力」ボタン押下
  onClickInput(event) {
    this.description = "本日は晴天なり。";
  }

  // 「登録」ボタン押下
  onClickSave(event) {
    let me = this;

    if (!this.description) {
      me.alertCtrl.create({
        title: 'Warning',
        subTitle: '音声入力ボタンを押して、活動内容を入力してください。',
        buttons: ['OK']
      }).present();
      return;
    }

    force.create("Task",
      {
        WhatId: this.accountid,
        Description: this.description,
        Status: "Completed"
      },
      function(){
        me.alertCtrl.create({
          title: 'Info',
          subTitle: '活動登録が完了しました。',
          buttons: ['OK']
        }).present();
      },
      function(error){
        me.alertCtrl.create({
          title: 'Error',
          subTitle: '活動登録に失敗しました。[' + error + ']',
          buttons: ['OK']
        }).present();
      });
  }

  // 「キャンセル」ボタン押下
  onClickCancel(event) {
    this.navCtrl.pop();
  }
}
