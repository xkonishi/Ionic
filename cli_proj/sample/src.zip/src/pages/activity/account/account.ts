import { Component } from '@angular/core';
import { AlertController } from 'ionic-angular'

// force.js
declare let force: any;

@Component({
  selector: 'page-account',
  templateUrl: 'account.html'
})
export class AccountActivityPage {
  accountid: string = "0012800001JwSFj";
  description: string;

  constructor(public alertCtrl: AlertController) {

  }

  // 「音声入力」ボタン押下
  onClickInput(event) {
    this.description = "本日は晴天なり。";
  }

  // 「登録」ボタン押下
  onClickSave(event) {
    let al = this.alertCtrl;

    if (!this.description) {
      al.create({
        title: 'Warning',
        subTitle: '音声入力ボタンを押して、活動内容を入力してください。',
        buttons: ['OK']
      }).present();
      return;
    }

    force.create("Task",
      {
        WhatId: this.accountid,
        Description: this.description,
        Status: "Completed"
      },
      function(){
        al.create({
          title: 'Info',
          subTitle: '活動登録が完了しました。',
          buttons: ['OK']
        }).present();
      },
      function(error){
        al.create({
          title: 'Error',
          subTitle: '活動登録に失敗しました。[' + error + ']',
          buttons: ['OK']
        }).present();
      });
  }

  onClickCancel(event) {
    //this.navCtrl.push(HomePage);

  }
}
