import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { AccountActivityPage } from '../activity/account/account';

// force.js
declare let force: any;

@Component({
  selector: 'page-account-list',
  templateUrl: 'account_list.html'
})
export class AccountListPage {
  items: Array<{id: string, name: string, address: string, industry: string}>;

  constructor(private navCtrl: NavController) {
    let me = this;

    force.query(
      "Select Id,Name,BillingAddress,Industry From Account",
      function(res){
        me.items = [];
        for (let i=0; i<res.records.length; i++) {
          let rec = res.records[i];
          me.items.push({
            id: rec.Id,
            name: rec.Name,
            address: rec.BillingAddress.state + rec.BillingAddress.city + rec.BillingAddress.street,
            industry: rec.Industry
          });
        }
      },
      function(error){
        console.error(error);
      })
  }

  // 取引先リストのタップ
  itemTapped(event, item) {
    this.navCtrl.push(AccountActivityPage, item);
  }
}
